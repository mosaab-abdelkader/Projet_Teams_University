package fr.sorbonne.paris.nord.university.api.service;

import fr.sorbonne.paris.nord.university.api.entity.Team;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface TeamService {
    List<Team> getAllTeams();
    Optional<Team> getTeamById(Long teamId);
    void addTeam (Team team);
    void updateTeam (Team team);
    void deleteTeamById (Long id);
}
