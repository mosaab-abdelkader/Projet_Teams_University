package fr.sorbonne.paris.nord.university.api.controller;


import fr.sorbonne.paris.nord.university.api.entity.Team;
import fr.sorbonne.paris.nord.university.api.repository.TeamRepository;
import fr.sorbonne.paris.nord.university.api.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
import java.awt.*;
import java.util.List;
import java.util.Optional;

@RestController

@RequestMapping("team")
public class TeamController {
    @Autowired
    private TeamService teamService;

    public TeamController(TeamService teamService){
        this.teamService=teamService;
    }


    @GetMapping("/hello")
    public String getTeams() {
        return "Hello World";
    }
    @GetMapping("/all")
    public List<Team> getAllTeams(){
        return teamService.getAllTeams();
    }

    @GetMapping(value ="/get/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
    public Optional<Team> getTeamById(@PathVariable("id") Long teamId){
        return teamService.getTeamById(teamId);
    }

    @PostMapping("/add")
    public void addTeam(Team team) {
        teamService.addTeam(team);
    }

    @PutMapping("/update")
    public void updateTeam(Team team) {
        teamService.updateTeam(team);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteTeamById(@PathVariable("id") Long teamId) {
        teamService.deleteTeamById(teamId);
    }
}