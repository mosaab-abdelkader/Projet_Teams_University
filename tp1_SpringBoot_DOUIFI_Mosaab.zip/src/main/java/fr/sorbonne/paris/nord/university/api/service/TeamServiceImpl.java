package fr.sorbonne.paris.nord.university.api.service;

import fr.sorbonne.paris.nord.university.api.entity.Team;
import fr.sorbonne.paris.nord.university.api.repository.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.swing.text.html.parser.Entity;
import java.util.List;
import java.util.Optional;

@Service
public class TeamServiceImpl  implements TeamService{
     @Autowired
    private TeamRepository teamrepository;


    @Override
    @Transactional(readOnly = true)
    public List<Team> getAllTeams() {
        return teamrepository.findAll();
    }

    @Transactional
    @Override
    public Optional<Team> getTeamById(Long teamId) {
        return teamrepository.findById(teamId);
    }

    @Transactional
    @Override
    public void addTeam(Team team) {

        teamrepository.save(team);
    }

    @Transactional
    @Override
    public void updateTeam(Team team) {
        long id = team.getId();
        final  Optional<Team> teamFromRepository = teamrepository.findById(id);

        if(teamFromRepository.isPresent()){
            Team entity = teamFromRepository.get();
            entity.setName(team.getName());
            entity.setSlogan(team.getSlogan());
            teamrepository.save(entity);
        }
    }

    @Transactional
    @Override
    public void deleteTeamById(Long id) {
        teamrepository.deleteById(id);
    }
}
