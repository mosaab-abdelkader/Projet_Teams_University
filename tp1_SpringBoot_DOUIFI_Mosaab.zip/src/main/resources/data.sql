INSERT INTO team (name, slogan) VALUES ('PSG', 'Revons plus grand');
INSERT INTO team (name, slogan) VALUES ('Real Madrid', 'Les galactiques');
INSERT INTO team (name, slogan) VALUES ('Barcelone', 'La Macia');
INSERT INTO team (name, slogan) VALUES ('Bayern', 'Les puissants en Allemagne');
INSERT INTO team (name, slogan) VALUES ('Manchester United', 'Les red devils');