package fr.sorbonne.paris.nord.university.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpTeamsHandlingApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
